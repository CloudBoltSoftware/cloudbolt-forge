A guide for the New Jupyter UI Extension is available on the CloudBolt Forge website: 
http://cloudboltsoftware.github.io/cloudbolt-forge/sites/NewJupyterXUI/jupyter.html