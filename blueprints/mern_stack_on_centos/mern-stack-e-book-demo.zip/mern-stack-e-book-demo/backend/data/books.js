const books = [{"title":"Sample Book","isbn":"ISBN0001","author":"Bharat Kumar","description":"This blueprint setup a production ready web server from scratch on the Amazon EC2 (Elastic Compute Cloud) service, then deploy a custom MERN Stack application to it that supports user registration and authentication. A MERN Stack application is made up of a front app built with React and React frontend is connected to backend api built with Node.js + Expressjs + MongoDB, hence the name MERN (MongoDB , Expressjs , React, Nodejs)","published_date":"2022-09-14T00:00:00.000Z","publisher":"Cloudbolt"}]

export default books

