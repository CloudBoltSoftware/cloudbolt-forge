const mongoURI = "mongodb_connection_string"

export default mongoURI
