export const API_BASE_URL = 'BACKEND_API_URL'

