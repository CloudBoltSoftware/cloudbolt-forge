from shared_modules.resource_utils import start_discovery
import shared_modules.azure_sql



RESOURCE_IDENTIFIER = ["name", "resource_group"]
AZURE_RESOURCE_TYPE = "Microsoft.Sql/servers/databases"


def resource_mapper(resource, resource_details, wrapper):
    dbname = resource_details.name

    # Skip default master db. We dont want to create a cb resource for these
    if dbname == "master":
        return None

    sql_server_name = resource_details.id.split("/")[8]

    # size
    size = "unknown size"
    if (
        resource_details.sku.name == "Standard"
        and resource_details.sku.tier == "Standard"
    ):
        size = "S"
    elif (
        resource_details.sku.name == "GP_S_Gen5"
        and resource_details.sku.tier == "GeneralPurpose"
        and resource_details.sku.family == "Gen5"
        and resource_details.sku.capacity == 4
    ):
        size = "M"
    elif (
        resource_details.sku.name == "GP_S_Gen5"
        and resource_details.sku.tier == "GeneralPurpose"
        and resource_details.sku.family == "Gen5"
        and resource_details.sku.capacity == 6
    ):
        size = "L"
    elif resource_details.sku.name == "ElasticPool":
        size = "POOLED"

    return {
        "name": dbname,
        "sql_server_name": sql_server_name,
        "collation": resource_details.properties["collation"],
        "sql_database_max_size_bytes": resource_details.properties["maxSizeBytes"],
        "size": size,
    }


def discover_resources(**kwargs):
    return start_discovery(AZURE_RESOURCE_TYPE, resource_mapper)